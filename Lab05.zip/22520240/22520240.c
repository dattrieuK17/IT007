#include <stdio.h>
#include <semaphore.h>
#include <pthread.h>
sem_t sem1, sem2, sem3, sem4, sem5, sem6, sem7, sem8;

double x1 = 2, x2 = 3, x3 = 4, x4 = 5, x5 = 6, x6 = 7, w, v, y, z, ans;

void* processA(void* mess){
    while(1){
        w = x1 * x2;
        printf("a) w = %.0f\n", w);
        sem_post(&sem3);
        sem_post(&sem5);
    }
}

void* processB(void* mess){
    while(1){
        v = x3 * x4;
        printf("b) v = %.0f\n", v);
        sem_post(&sem1);
        sem_post(&sem2);
    }
}

void* processC(void* mess){
    while(1){
        sem_wait(&sem1);
        y = v * x5;
        printf("c) y = %.0f\n", y);
        sem_post(&sem4);
    }
}

void* processD(void* mess){
    while(1){
        sem_wait(&sem2);
        z = v * x6;
        printf("d) z = %.0f\n", z);
        sem_post(&sem6);
    
    }
}

void* processE(void* mess){
    while(1){
        sem_wait(&sem3);
        sem_wait(&sem4);
        y = w * y;
        printf("e) y = %.0f\n", y);
        sem_post(&sem7);
    }
}

void* processF(void* mess){
    while(1){
        sem_wait(&sem5);
        sem_wait(&sem6);
        z = w * z;
        printf("f) z = %.0f\n", z);
        sem_post(&sem8);
    }
}

void* processG(void* mess){
    while(1){
        sem_wait(&sem7);
        sem_wait(&sem8);
        ans = y + z;
        printf("g) ans = %.0f\n", ans);
    }
}

int main(){
    sem_init(&sem1, 0, 0);
    sem_init(&sem2, 0, 0);
    sem_init(&sem3, 0, 0);
    sem_init(&sem4, 0, 0);
    sem_init(&sem5, 0, 0);
    sem_init(&sem6, 0, 0);
    sem_init(&sem7, 0, 0);
    sem_init(&sem8, 0, 0);
    pthread_t pA, pB, pC, pD, pE, pF, pG;
    pthread_create(&pA, NULL, &processA, NULL);
    pthread_create(&pB, NULL, &processB, NULL);
    pthread_create(&pC, NULL, &processC, NULL);
    pthread_create(&pD, NULL, &processD, NULL);
    pthread_create(&pE, NULL, &processE, NULL);
    pthread_create(&pF, NULL, &processF, NULL);
    pthread_create(&pG, NULL, &processG, NULL);
    while(1){};
    return 0;

}

