#include <stdio.h>

#define SORT_BY_ARRIVAL 0
#define SORT_BY_PID 1
#define SORT_BY_BURST 2

typedef struct{
    int name;
    int arrival, burst;
    int firstRespone, finish, waiting, tat;
}PCB;

int n; // Số tiến trình nhập vào
PCB burstArr[100]; // Mảng lưu trữ thông tin của tiến trình thứ i. Thông tin bao gồm name và burst
PCB finishProcess[100]; // Mảng lưu trữ thông tin của các tiến trình đã thực thi xong
int j = 0; // index của mảng finishProcess

// Hàm nhập thông tin tiến trình
void inputProcess(PCB p[], int *n){
    FILE* fptr = fopen("input.txt", "r");
    fscanf(fptr, "%d", &(*n));
    for(int i=0; i< *n; i++){
        int data;
        fscanf(fptr, "%d", &data);
        p[i].name = data; 
        burstArr[i].name = data;
        fscanf(fptr, "%d", &data);
        p[i].arrival = data;
        fscanf(fptr, "%d", &data);
        p[i].burst = data;
        burstArr[i].burst = data;
        p[i].firstRespone = -1, p[i].finish = -1; //Khởi tạo giá trị firstRespone và finish = -1 để tiện trong việc quản lí
    }
}

// Hàm in thông tin của tiến trình. Thông tin bao gồm name, firstRespone, waiting time, turn around time
void printProcess(PCB p[], int n){
    for (int i = 0; i < n; i++){
        printf("%d ", p[i].name);
        printf("%d ", p[i].firstRespone);
        printf("%d ", p[i].waiting);
        printf("%d \n", p[i].tat);     
    }
}

// Swap thông tin 2 tiến trình. Dùng cho hàm sort
void swap(PCB *a, PCB *b){
    PCB tmp = *a;
    *a = *b;
    *b = tmp;
}

// Sắp xếp tăng dần theo tiêu chí choice(Arrival, Burst, Name)
void sort(PCB p[], int n, int choice){
    switch(choice){
        case(0):
            for (int i = 0; i<n-1; i++)
                for (int j = i+1; j<n; j++)
                    if (p[i].arrival > p[j].arrival)
                        swap(&p[i], &p[j]);
            break;
        case(1):
            for (int i = 0; i<n-1; i++)
                for (int j = i+1; j<n; j++)
                    if (p[i].name > p[j].name)
                        swap(&p[i], &p[j]);
            break;
        case(2):
            for (int i = 0; i<n-1; i++)
                for (int j = i+1; j<n; j++)
                    if (p[i].burst > p[j].burst)
                        swap(&p[i], &p[j]);
            break;
        default:
            break;
    }
}

// Xóa tiến trình đầu tiên ra khỏi mảng
void deleteProcess(PCB p[], int *n){
    for (int i=0; i<*n-1; i++){
        p[i] = p[i+1]; 
    }
    (*n)--;
}

// Hàm xử lí
void processing(PCB p[], int n){
    sort(p, n, SORT_BY_ARRIVAL); // Sort theo Arrival tiến trình nào đến trước sẽ được thực thi trước
    int i = 1, burst = 0, maxArri = p[n-1].arrival, pSize; /* i là index cho mảng p, burst dùng để xác định thời điểm của quá trình xử lí, 
maxArri là giá trị Arrival của tiến trình đến cuối cùng*/
    int flag; // Nếu flag = 1 có nghĩa là burst < p[i].arrival nhưng p[0].burst đã = 0
    //Xử lí từ khi burst = 0 đến khi burst = maxArr
    while(burst < maxArri){
        flag = 0;
        while (burst < p[i].arrival){
            if (p[0].firstRespone == -1) // Nếu tiến trình chưa được thực thi lần nào thì sẽ firstRespone sẽ được gán = burst
                p[0].firstRespone = burst;
            p[0].burst --; // Mỗi vòng lặp while thì p[0].burst sẽ giảm 1 còn burst sẽ tăng thêm 1
            burst ++;
            if (p[0].burst == 0){
                p[0].finish = burst;
                finishProcess[j++] = p[0];
                deleteProcess(p, &n);
                flag = 1;
                break;
            }
        }
        if (flag)
            sort(p, --i, SORT_BY_BURST); // Lúc này p[i] vẫn chưa xuất hiện nên không cần sort và p[0] vừa bị xóa nên i phải giảm xuống
        else     
            sort(p, ++i, SORT_BY_BURST); // Lúc này p[i] đã xuất hiện nên cần phải sort luôn cả p[0] -> p[i]
    }
    // Xử lí từ burst = maxArr đến khi tất cả tiến trình hoàn thành, tương tự như sjf
    pSize = n;
    for (int i = 0; i < pSize; i++){
        if (p[0].firstRespone == -1)
                p[0].firstRespone = burst;
        burst += p[0].burst;
        p[0].burst = 0;
        p[0].finish = burst;
        finishProcess[j++] = p[0];
        deleteProcess(p, &n);
        sort(p, n, SORT_BY_BURST);
    }
}
int main(){
    PCB p[10];
    float avgwaittime = 0, avgtat = 0;
    inputProcess(p, &n);
    processing(p, n);
    sort(finishProcess, j, SORT_BY_PID);
    sort(burstArr, j, SORT_BY_PID);
    for (int i = 0; i < j; i++){
        finishProcess[i].tat = finishProcess[i].finish - finishProcess[i].arrival; // TAT = finish - arrival
        finishProcess[i].waiting = finishProcess[i].finish - finishProcess[i].arrival - burstArr[i].burst; // waiting time = finish - arrival - burst
    }
    for (int i = 0; i < j; i++){
        avgwaittime += finishProcess[i].waiting;
        avgtat += finishProcess[i].tat;
    }
    printProcess(finishProcess, j);
    printf("%.2f\n", avgwaittime/j);
    printf("%.2f", avgtat/j);
}