#include <unistd.h>
int main(){
    execlp("./hello", "hello", NULL);
    return 0;
}
/* 
    - Các hàm execl(), execlp(), execle(), exect(), và execv() đều là các hàm 
được cung cấp bởi thư viện tiêu chuẩn C để thực thi một chương trình khác trong 
chương trình hiện tại. Tuy nhiên, chúng có một số khác biệt như sau:
+ execl() và execv() đều được sử dụng để thực thi một chương trình khác, nhưng 
cách truyền các đối số khác nhau. Hàm execl() yêu cầu danh sách các đối số được 
truyền dưới dạng danh sách các tham số, trong khi hàm execv() yêu cầu danh sách 
các đối số được truyền dưới dạng một mảng các chuỗi kết thúc bằng NULL.
+ Hàm execlp() và execvp() tương tự như execl() và execv(), nhưng thay vì yêu 
cầu đường dẫn đầy đủ đến chương trình cần thực thi, chúng sử dụng biến môi 
trường PATH để tìm kiếm chương trình.
+ Hàm execle() yêu cầu một danh sách các biến môi trường được truyền vào, trong 
khi hàm exect() không yêu cầu bất kỳ đối số nào.
    - Tất cả các hàm này đều sẽ thay thế tiến trình hiện tại bằng tiến trình mới 
được chỉ định nếu thành công.
*/
