
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/wait.h>
#include <sys/types.h>
#include <signal.h>

pid_t pid;
int loop = 1;

void on_sigint(){
    loop = 0;
    kill(pid, SIGINT);
    printf("\ncount.sh has stopped! Goodbye!\n");
    fflush(stdout);
    exit(0);
}
int main(int argc, char* argv[])    
{
    printf("Welcome to IT007, I am 22520240!\n");
    
    pid = fork();

    if (pid == 0)
        execl("./count.sh", "./count.sh", "120", NULL);
    else 
        signal(SIGINT, on_sigint);
        
    while(loop){};
    return 0;
}