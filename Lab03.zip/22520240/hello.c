#include <stdio.h>

int main(){
    printf("Hello, i am Trieu Tan Dat\n");
    printf("Welcome to IT007! \n");
}