#!/bin/sh

if test -e $2
then
if grep -q "$1" $2
then
echo "Trong tap tin $2 co chuoi $1" > kq.txt
else
echo "Trong tap tin $2 khong co chuoi $1" > kq.txt
fi
else
echo "Tap tin $2 khong ton tai" > kq.txt
fi
exit 0
