#!/bin/sh

nam=$1
thang=$2
tenfile=$3
if [ $nam -lt 1901 ]
then
echo "Nam khong hop le" > $tenfile
exit 1
fi
if [ $thang -gt 12 ] || [ $thang -lt 1 ]
then
echo "Thang khong hop le" > $tenfile
exit 1
fi

ngay=0
case $thang in
	1 | 3 | 5 | 7 | 8 | 10 | 12) 
		ngay=31;;
	2) 
		if [ $(($1 % 4)) -eq 0 ] && [ $(($1 % 100)) -ne 0 ] || [ $(($1 % 400)) -eq 0 ]
		then
			ngay=29
		else
			ngay=28
		fi;;
	4 | 6 | 9 | 11) 
		ngay=30;;
esac
echo $ngay > $tenfile
exit 0
